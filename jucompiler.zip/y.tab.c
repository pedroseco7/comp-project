/* A Bison parser, made by GNU Bison 3.8.2.  */

/* Bison implementation for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2021 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <https://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* DO NOT RELY ON FEATURES THAT ARE NOT DOCUMENTED in the manual,
   especially those whose name start with YY_ or yy_.  They are
   private implementation details that can be changed or removed.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output, and Bison version.  */
#define YYBISON 30802

/* Bison version string.  */
#define YYBISON_VERSION "3.8.2"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1




/* First part of user prologue.  */
#line 1 "jucompiler.y"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "semantics.h" 

int yylex(void);
void yyerror(char *);
struct node *ast;
int print_sym = 0;

/* Protótipos para evitar o erro de "implicit declaration" */
struct node *newnode(enum category category, char *token);
void addchild(struct node *parent, struct node *child);
void show(struct node *node, int depth);
void free_list_and_node(struct node *n);
void codegen_program(struct node *program);

extern int cur_line, cur_col;
extern char *yytext;
extern int error_line, error_col;
extern char error_yytext[];

#line 95 "y.tab.c"

# ifndef YY_CAST
#  ifdef __cplusplus
#   define YY_CAST(Type, Val) static_cast<Type> (Val)
#   define YY_REINTERPRET_CAST(Type, Val) reinterpret_cast<Type> (Val)
#  else
#   define YY_CAST(Type, Val) ((Type) (Val))
#   define YY_REINTERPRET_CAST(Type, Val) ((Type) (Val))
#  endif
# endif
# ifndef YY_NULLPTR
#  if defined __cplusplus
#   if 201103L <= __cplusplus
#    define YY_NULLPTR nullptr
#   else
#    define YY_NULLPTR 0
#   endif
#  else
#   define YY_NULLPTR ((void*)0)
#  endif
# endif

/* Use api.header.include to #include this header
   instead of duplicating it here.  */
#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 1
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token kinds.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     /* "end of file"  */
    YYerror = 256,                 /* error  */
    YYUNDEF = 257,                 /* "invalid token"  */
    AND = 258,                     /* AND  */
    ASSIGN = 259,                  /* ASSIGN  */
    STAR = 260,                    /* STAR  */
    COMMA = 261,                   /* COMMA  */
    DIV = 262,                     /* DIV  */
    EQ = 263,                      /* EQ  */
    GE = 264,                      /* GE  */
    GT = 265,                      /* GT  */
    LBRACE = 266,                  /* LBRACE  */
    LE = 267,                      /* LE  */
    LPAR = 268,                    /* LPAR  */
    LSQ = 269,                     /* LSQ  */
    LT = 270,                      /* LT  */
    MINUS = 271,                   /* MINUS  */
    MOD = 272,                     /* MOD  */
    NE = 273,                      /* NE  */
    NOT = 274,                     /* NOT  */
    OR = 275,                      /* OR  */
    PLUS = 276,                    /* PLUS  */
    RBRACE = 277,                  /* RBRACE  */
    RPAR = 278,                    /* RPAR  */
    RSQ = 279,                     /* RSQ  */
    SEMICOLON = 280,               /* SEMICOLON  */
    ARROW = 281,                   /* ARROW  */
    LSHIFT = 282,                  /* LSHIFT  */
    RSHIFT = 283,                  /* RSHIFT  */
    XOR = 284,                     /* XOR  */
    BOOL = 285,                    /* BOOL  */
    CLASS = 286,                   /* CLASS  */
    DOTLENGTH = 287,               /* DOTLENGTH  */
    DOUBLE = 288,                  /* DOUBLE  */
    ELSE = 289,                    /* ELSE  */
    IF = 290,                      /* IF  */
    INT = 291,                     /* INT  */
    PRINT = 292,                   /* PRINT  */
    PARSEINT = 293,                /* PARSEINT  */
    PUBLIC = 294,                  /* PUBLIC  */
    RETURN = 295,                  /* RETURN  */
    STATIC = 296,                  /* STATIC  */
    STRING = 297,                  /* STRING  */
    VOID = 298,                    /* VOID  */
    WHILE = 299,                   /* WHILE  */
    RESERVED = 300,                /* RESERVED  */
    IDENTIFIER = 301,              /* IDENTIFIER  */
    NATURAL = 302,                 /* NATURAL  */
    DECIMAL = 303,                 /* DECIMAL  */
    STRLIT = 304,                  /* STRLIT  */
    BOOLLIT = 305,                 /* BOOLLIT  */
    IF_NO_ELSE = 306               /* IF_NO_ELSE  */
  };
  typedef enum yytokentype yytoken_kind_t;
#endif
/* Token kinds.  */
#define YYEMPTY -2
#define YYEOF 0
#define YYerror 256
#define YYUNDEF 257
#define AND 258
#define ASSIGN 259
#define STAR 260
#define COMMA 261
#define DIV 262
#define EQ 263
#define GE 264
#define GT 265
#define LBRACE 266
#define LE 267
#define LPAR 268
#define LSQ 269
#define LT 270
#define MINUS 271
#define MOD 272
#define NE 273
#define NOT 274
#define OR 275
#define PLUS 276
#define RBRACE 277
#define RPAR 278
#define RSQ 279
#define SEMICOLON 280
#define ARROW 281
#define LSHIFT 282
#define RSHIFT 283
#define XOR 284
#define BOOL 285
#define CLASS 286
#define DOTLENGTH 287
#define DOUBLE 288
#define ELSE 289
#define IF 290
#define INT 291
#define PRINT 292
#define PARSEINT 293
#define PUBLIC 294
#define RETURN 295
#define STATIC 296
#define STRING 297
#define VOID 298
#define WHILE 299
#define RESERVED 300
#define IDENTIFIER 301
#define NATURAL 302
#define DECIMAL 303
#define STRLIT 304
#define BOOLLIT 305
#define IF_NO_ELSE 306

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 25 "jucompiler.y"

    struct {
        char *id;
        int line;
        int col;
    } info;
    struct node *node;

#line 259 "y.tab.c"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;


int yyparse (void);


#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
/* Symbol kind.  */
enum yysymbol_kind_t
{
  YYSYMBOL_YYEMPTY = -2,
  YYSYMBOL_YYEOF = 0,                      /* "end of file"  */
  YYSYMBOL_YYerror = 1,                    /* error  */
  YYSYMBOL_YYUNDEF = 2,                    /* "invalid token"  */
  YYSYMBOL_AND = 3,                        /* AND  */
  YYSYMBOL_ASSIGN = 4,                     /* ASSIGN  */
  YYSYMBOL_STAR = 5,                       /* STAR  */
  YYSYMBOL_COMMA = 6,                      /* COMMA  */
  YYSYMBOL_DIV = 7,                        /* DIV  */
  YYSYMBOL_EQ = 8,                         /* EQ  */
  YYSYMBOL_GE = 9,                         /* GE  */
  YYSYMBOL_GT = 10,                        /* GT  */
  YYSYMBOL_LBRACE = 11,                    /* LBRACE  */
  YYSYMBOL_LE = 12,                        /* LE  */
  YYSYMBOL_LPAR = 13,                      /* LPAR  */
  YYSYMBOL_LSQ = 14,                       /* LSQ  */
  YYSYMBOL_LT = 15,                        /* LT  */
  YYSYMBOL_MINUS = 16,                     /* MINUS  */
  YYSYMBOL_MOD = 17,                       /* MOD  */
  YYSYMBOL_NE = 18,                        /* NE  */
  YYSYMBOL_NOT = 19,                       /* NOT  */
  YYSYMBOL_OR = 20,                        /* OR  */
  YYSYMBOL_PLUS = 21,                      /* PLUS  */
  YYSYMBOL_RBRACE = 22,                    /* RBRACE  */
  YYSYMBOL_RPAR = 23,                      /* RPAR  */
  YYSYMBOL_RSQ = 24,                       /* RSQ  */
  YYSYMBOL_SEMICOLON = 25,                 /* SEMICOLON  */
  YYSYMBOL_ARROW = 26,                     /* ARROW  */
  YYSYMBOL_LSHIFT = 27,                    /* LSHIFT  */
  YYSYMBOL_RSHIFT = 28,                    /* RSHIFT  */
  YYSYMBOL_XOR = 29,                       /* XOR  */
  YYSYMBOL_BOOL = 30,                      /* BOOL  */
  YYSYMBOL_CLASS = 31,                     /* CLASS  */
  YYSYMBOL_DOTLENGTH = 32,                 /* DOTLENGTH  */
  YYSYMBOL_DOUBLE = 33,                    /* DOUBLE  */
  YYSYMBOL_ELSE = 34,                      /* ELSE  */
  YYSYMBOL_IF = 35,                        /* IF  */
  YYSYMBOL_INT = 36,                       /* INT  */
  YYSYMBOL_PRINT = 37,                     /* PRINT  */
  YYSYMBOL_PARSEINT = 38,                  /* PARSEINT  */
  YYSYMBOL_PUBLIC = 39,                    /* PUBLIC  */
  YYSYMBOL_RETURN = 40,                    /* RETURN  */
  YYSYMBOL_STATIC = 41,                    /* STATIC  */
  YYSYMBOL_STRING = 42,                    /* STRING  */
  YYSYMBOL_VOID = 43,                      /* VOID  */
  YYSYMBOL_WHILE = 44,                     /* WHILE  */
  YYSYMBOL_RESERVED = 45,                  /* RESERVED  */
  YYSYMBOL_IDENTIFIER = 46,                /* IDENTIFIER  */
  YYSYMBOL_NATURAL = 47,                   /* NATURAL  */
  YYSYMBOL_DECIMAL = 48,                   /* DECIMAL  */
  YYSYMBOL_STRLIT = 49,                    /* STRLIT  */
  YYSYMBOL_BOOLLIT = 50,                   /* BOOLLIT  */
  YYSYMBOL_IF_NO_ELSE = 51,                /* IF_NO_ELSE  */
  YYSYMBOL_YYACCEPT = 52,                  /* $accept  */
  YYSYMBOL_Program = 53,                   /* Program  */
  YYSYMBOL_ProgramDecls = 54,              /* ProgramDecls  */
  YYSYMBOL_MethodDecl = 55,                /* MethodDecl  */
  YYSYMBOL_FieldDecl = 56,                 /* FieldDecl  */
  YYSYMBOL_Type = 57,                      /* Type  */
  YYSYMBOL_MethodHeader = 58,              /* MethodHeader  */
  YYSYMBOL_MethodParams = 59,              /* MethodParams  */
  YYSYMBOL_FormalParams = 60,              /* FormalParams  */
  YYSYMBOL_FormalParamsList = 61,          /* FormalParamsList  */
  YYSYMBOL_MethodBody = 62,                /* MethodBody  */
  YYSYMBOL_MethodBodyDecls = 63,           /* MethodBodyDecls  */
  YYSYMBOL_VarDecl = 64,                   /* VarDecl  */
  YYSYMBOL_IdList = 65,                    /* IdList  */
  YYSYMBOL_Statement = 66,                 /* Statement  */
  YYSYMBOL_StatementList = 67,             /* StatementList  */
  YYSYMBOL_MethodInvocation = 68,          /* MethodInvocation  */
  YYSYMBOL_Assignment = 69,                /* Assignment  */
  YYSYMBOL_ParseArgs = 70,                 /* ParseArgs  */
  YYSYMBOL_ExprList = 71,                  /* ExprList  */
  YYSYMBOL_Expr = 72,                      /* Expr  */
  YYSYMBOL_ExprOr = 73,                    /* ExprOr  */
  YYSYMBOL_ExprAnd = 74,                   /* ExprAnd  */
  YYSYMBOL_ExprXor = 75,                   /* ExprXor  */
  YYSYMBOL_ExprEq = 76,                    /* ExprEq  */
  YYSYMBOL_ExprRel = 77,                   /* ExprRel  */
  YYSYMBOL_ExprShift = 78,                 /* ExprShift  */
  YYSYMBOL_ExprAdd = 79,                   /* ExprAdd  */
  YYSYMBOL_ExprMult = 80,                  /* ExprMult  */
  YYSYMBOL_ExprUnary = 81,                 /* ExprUnary  */
  YYSYMBOL_ExprPostfix = 82                /* ExprPostfix  */
};
typedef enum yysymbol_kind_t yysymbol_kind_t;




#ifdef short
# undef short
#endif

/* On compilers that do not define __PTRDIFF_MAX__ etc., make sure
   <limits.h> and (if available) <stdint.h> are included
   so that the code can choose integer types of a good width.  */

#ifndef __PTRDIFF_MAX__
# include <limits.h> /* INFRINGES ON USER NAME SPACE */
# if defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stdint.h> /* INFRINGES ON USER NAME SPACE */
#  define YY_STDINT_H
# endif
#endif

/* Narrow types that promote to a signed type and that can represent a
   signed or unsigned integer of at least N bits.  In tables they can
   save space and decrease cache pressure.  Promoting to a signed type
   helps avoid bugs in integer arithmetic.  */

#ifdef __INT_LEAST8_MAX__
typedef __INT_LEAST8_TYPE__ yytype_int8;
#elif defined YY_STDINT_H
typedef int_least8_t yytype_int8;
#else
typedef signed char yytype_int8;
#endif

#ifdef __INT_LEAST16_MAX__
typedef __INT_LEAST16_TYPE__ yytype_int16;
#elif defined YY_STDINT_H
typedef int_least16_t yytype_int16;
#else
typedef short yytype_int16;
#endif

/* Work around bug in HP-UX 11.23, which defines these macros
   incorrectly for preprocessor constants.  This workaround can likely
   be removed in 2023, as HPE has promised support for HP-UX 11.23
   (aka HP-UX 11i v2) only through the end of 2022; see Table 2 of
   <https://h20195.www2.hpe.com/V2/getpdf.aspx/4AA4-7673ENW.pdf>.  */
#ifdef __hpux
# undef UINT_LEAST8_MAX
# undef UINT_LEAST16_MAX
# define UINT_LEAST8_MAX 255
# define UINT_LEAST16_MAX 65535
#endif

#if defined __UINT_LEAST8_MAX__ && __UINT_LEAST8_MAX__ <= __INT_MAX__
typedef __UINT_LEAST8_TYPE__ yytype_uint8;
#elif (!defined __UINT_LEAST8_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST8_MAX <= INT_MAX)
typedef uint_least8_t yytype_uint8;
#elif !defined __UINT_LEAST8_MAX__ && UCHAR_MAX <= INT_MAX
typedef unsigned char yytype_uint8;
#else
typedef short yytype_uint8;
#endif

#if defined __UINT_LEAST16_MAX__ && __UINT_LEAST16_MAX__ <= __INT_MAX__
typedef __UINT_LEAST16_TYPE__ yytype_uint16;
#elif (!defined __UINT_LEAST16_MAX__ && defined YY_STDINT_H \
       && UINT_LEAST16_MAX <= INT_MAX)
typedef uint_least16_t yytype_uint16;
#elif !defined __UINT_LEAST16_MAX__ && USHRT_MAX <= INT_MAX
typedef unsigned short yytype_uint16;
#else
typedef int yytype_uint16;
#endif

#ifndef YYPTRDIFF_T
# if defined __PTRDIFF_TYPE__ && defined __PTRDIFF_MAX__
#  define YYPTRDIFF_T __PTRDIFF_TYPE__
#  define YYPTRDIFF_MAXIMUM __PTRDIFF_MAX__
# elif defined PTRDIFF_MAX
#  ifndef ptrdiff_t
#   include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  endif
#  define YYPTRDIFF_T ptrdiff_t
#  define YYPTRDIFF_MAXIMUM PTRDIFF_MAX
# else
#  define YYPTRDIFF_T long
#  define YYPTRDIFF_MAXIMUM LONG_MAX
# endif
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif defined __STDC_VERSION__ && 199901 <= __STDC_VERSION__
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned
# endif
#endif

#define YYSIZE_MAXIMUM                                  \
  YY_CAST (YYPTRDIFF_T,                                 \
           (YYPTRDIFF_MAXIMUM < YY_CAST (YYSIZE_T, -1)  \
            ? YYPTRDIFF_MAXIMUM                         \
            : YY_CAST (YYSIZE_T, -1)))

#define YYSIZEOF(X) YY_CAST (YYPTRDIFF_T, sizeof (X))


/* Stored state numbers (used for stacks). */
typedef yytype_uint8 yy_state_t;

/* State numbers in computations.  */
typedef int yy_state_fast_t;

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(Msgid) dgettext ("bison-runtime", Msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(Msgid) Msgid
# endif
#endif


#ifndef YY_ATTRIBUTE_PURE
# if defined __GNUC__ && 2 < __GNUC__ + (96 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_PURE __attribute__ ((__pure__))
# else
#  define YY_ATTRIBUTE_PURE
# endif
#endif

#ifndef YY_ATTRIBUTE_UNUSED
# if defined __GNUC__ && 2 < __GNUC__ + (7 <= __GNUC_MINOR__)
#  define YY_ATTRIBUTE_UNUSED __attribute__ ((__unused__))
# else
#  define YY_ATTRIBUTE_UNUSED
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YY_USE(E) ((void) (E))
#else
# define YY_USE(E) /* empty */
#endif

/* Suppress an incorrect diagnostic about yylval being uninitialized.  */
#if defined __GNUC__ && ! defined __ICC && 406 <= __GNUC__ * 100 + __GNUC_MINOR__
# if __GNUC__ * 100 + __GNUC_MINOR__ < 407
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")
# else
#  define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN                           \
    _Pragma ("GCC diagnostic push")                                     \
    _Pragma ("GCC diagnostic ignored \"-Wuninitialized\"")              \
    _Pragma ("GCC diagnostic ignored \"-Wmaybe-uninitialized\"")
# endif
# define YY_IGNORE_MAYBE_UNINITIALIZED_END      \
    _Pragma ("GCC diagnostic pop")
#else
# define YY_INITIAL_VALUE(Value) Value
#endif
#ifndef YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
# define YY_IGNORE_MAYBE_UNINITIALIZED_END
#endif
#ifndef YY_INITIAL_VALUE
# define YY_INITIAL_VALUE(Value) /* Nothing. */
#endif

#if defined __cplusplus && defined __GNUC__ && ! defined __ICC && 6 <= __GNUC__
# define YY_IGNORE_USELESS_CAST_BEGIN                          \
    _Pragma ("GCC diagnostic push")                            \
    _Pragma ("GCC diagnostic ignored \"-Wuseless-cast\"")
# define YY_IGNORE_USELESS_CAST_END            \
    _Pragma ("GCC diagnostic pop")
#endif
#ifndef YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_BEGIN
# define YY_IGNORE_USELESS_CAST_END
#endif


#define YY_ASSERT(E) ((void) (0 && (E)))

#if !defined yyoverflow

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
      /* Use EXIT_SUCCESS as a witness for stdlib.h.  */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's 'empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
             && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* !defined yyoverflow */

#if (! defined yyoverflow \
     && (! defined __cplusplus \
         || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yy_state_t yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (YYSIZEOF (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (YYSIZEOF (yy_state_t) + YYSIZEOF (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)                           \
    do                                                                  \
      {                                                                 \
        YYPTRDIFF_T yynewbytes;                                         \
        YYCOPY (&yyptr->Stack_alloc, Stack, yysize);                    \
        Stack = &yyptr->Stack_alloc;                                    \
        yynewbytes = yystacksize * YYSIZEOF (*Stack) + YYSTACK_GAP_MAXIMUM; \
        yyptr += yynewbytes / YYSIZEOF (*yyptr);                        \
      }                                                                 \
    while (0)

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from SRC to DST.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(Dst, Src, Count) \
      __builtin_memcpy (Dst, Src, YY_CAST (YYSIZE_T, (Count)) * sizeof (*(Src)))
#  else
#   define YYCOPY(Dst, Src, Count)              \
      do                                        \
        {                                       \
          YYPTRDIFF_T yyi;                      \
          for (yyi = 0; yyi < (Count); yyi++)   \
            (Dst)[yyi] = (Src)[yyi];            \
        }                                       \
      while (0)
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  4
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   249

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  52
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  31
/* YYNRULES -- Number of rules.  */
#define YYNRULES  89
/* YYNSTATES -- Number of states.  */
#define YYNSTATES  174

/* YYMAXUTOK -- Last valid token kind.  */
#define YYMAXUTOK   306


/* YYTRANSLATE(TOKEN-NUM) -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex, with out-of-bounds checking.  */
#define YYTRANSLATE(YYX)                                \
  (0 <= (YYX) && (YYX) <= YYMAXUTOK                     \
   ? YY_CAST (yysymbol_kind_t, yytranslate[YYX])        \
   : YYSYMBOL_YYUNDEF)

/* YYTRANSLATE[TOKEN-NUM] -- Symbol number corresponding to TOKEN-NUM
   as returned by yylex.  */
static const yytype_int8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51
};

#if YYDEBUG
/* YYRLINE[YYN] -- Source line where rule number YYN was defined.  */
static const yytype_int16 yyrline[] =
{
       0,    45,    45,    62,    67,    79,    80,    83,    90,   111,
     114,   115,   116,   119,   127,   137,   148,   151,   168,   180,
     190,   193,   206,   211,   223,   226,   249,   256,   259,   286,
     293,   300,   306,   311,   317,   318,   319,   320,   321,   326,
     333,   336,   342,   345,   354,   369,   372,   383,   393,   396,
     401,   408,   409,   412,   414,   417,   419,   422,   424,   427,
     429,   431,   434,   436,   438,   440,   442,   445,   447,   449,
     452,   454,   456,   459,   461,   463,   465,   468,   469,   470,
     471,   474,   475,   476,   485,   486,   487,   488,   489,   490
};
#endif

/** Accessing symbol of state STATE.  */
#define YY_ACCESSING_SYMBOL(State) YY_CAST (yysymbol_kind_t, yystos[State])

#if YYDEBUG || 0
/* The user-facing name of the symbol whose (internal) number is
   YYSYMBOL.  No bounds checking.  */
static const char *yysymbol_name (yysymbol_kind_t yysymbol) YY_ATTRIBUTE_UNUSED;

/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "\"end of file\"", "error", "\"invalid token\"", "AND", "ASSIGN",
  "STAR", "COMMA", "DIV", "EQ", "GE", "GT", "LBRACE", "LE", "LPAR", "LSQ",
  "LT", "MINUS", "MOD", "NE", "NOT", "OR", "PLUS", "RBRACE", "RPAR", "RSQ",
  "SEMICOLON", "ARROW", "LSHIFT", "RSHIFT", "XOR", "BOOL", "CLASS",
  "DOTLENGTH", "DOUBLE", "ELSE", "IF", "INT", "PRINT", "PARSEINT",
  "PUBLIC", "RETURN", "STATIC", "STRING", "VOID", "WHILE", "RESERVED",
  "IDENTIFIER", "NATURAL", "DECIMAL", "STRLIT", "BOOLLIT", "IF_NO_ELSE",
  "$accept", "Program", "ProgramDecls", "MethodDecl", "FieldDecl", "Type",
  "MethodHeader", "MethodParams", "FormalParams", "FormalParamsList",
  "MethodBody", "MethodBodyDecls", "VarDecl", "IdList", "Statement",
  "StatementList", "MethodInvocation", "Assignment", "ParseArgs",
  "ExprList", "Expr", "ExprOr", "ExprAnd", "ExprXor", "ExprEq", "ExprRel",
  "ExprShift", "ExprAdd", "ExprMult", "ExprUnary", "ExprPostfix", YY_NULLPTR
};

static const char *
yysymbol_name (yysymbol_kind_t yysymbol)
{
  return yytname[yysymbol];
}
#endif

#define YYPACT_NINF (-59)

#define yypact_value_is_default(Yyn) \
  ((Yyn) == YYPACT_NINF)

#define YYTABLE_NINF (-1)

#define yytable_value_is_error(Yyn) \
  0

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
static const yytype_int16 yypact[] =
{
     -10,   -19,    50,    59,   -59,   -59,    17,    49,   -59,   -59,
      58,   -59,   -59,   -59,   -14,   -59,   -59,   -59,    44,    55,
      86,    92,   101,   -59,   -59,    62,    62,     8,   116,   107,
      82,   109,   -59,   110,    88,   -59,   111,   -59,   -59,   -59,
     124,   126,   127,   145,   135,    41,   104,   -59,   -59,   122,
     130,   132,   139,   -59,   -59,   -59,   -59,   -59,    56,   181,
     160,     7,    39,   199,   199,   199,   -59,    11,   -59,   -59,
     -59,   -59,   -59,   -59,   140,   147,   165,   146,    51,   103,
      34,     4,     6,   -59,   -59,   181,   181,    25,   -59,   -59,
     -59,   -59,   131,   176,   -59,   -59,   161,   162,   163,   164,
     174,   166,   167,    15,   -59,   -59,   -59,   -59,   -59,   199,
     199,   199,   199,   199,   199,   199,   199,   199,   199,   199,
     199,   199,   199,   199,   199,   173,   -59,   178,   -59,    28,
     -59,    43,   -59,    46,   134,   179,   180,   -59,   181,   -59,
     -59,   165,   146,    51,   103,   103,    34,    34,    34,    34,
       4,     4,     6,     6,   -59,   -59,   -59,   134,   -59,   181,
     -59,   -59,   153,   169,   -59,   -59,   187,   -59,   -59,   -59,
     134,   190,   -59,   -59
};

/* YYDEFACT[STATE-NUM] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE does not specify something else to do.  Zero
   means the default is an error.  */
static const yytype_int8 yydefact[] =
{
       0,     0,     0,     0,     1,     6,     0,     0,     2,     5,
       0,     3,     4,     9,     0,    10,    12,    11,     0,     0,
       0,     0,    27,    24,     7,    16,    16,     0,     0,     0,
       0,     0,    15,     0,     0,     8,     0,    42,    21,    37,
       0,     0,     0,     0,     0,     0,     0,    23,    22,     0,
       0,     0,     0,    20,    14,    13,    26,    40,     0,     0,
       0,     0,     0,     0,     0,     0,    32,    84,    85,    86,
      87,    81,    51,    82,     0,    52,    54,    56,    58,    61,
      66,    69,    72,    76,    80,     0,     0,     0,    27,    34,
      35,    36,     0,    17,    28,    41,     0,     0,     0,     0,
       0,     0,     0,    84,    78,    79,    77,    83,    33,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,    46,     0,    43,     0,
      49,     0,    18,     0,     0,     0,     0,    48,     0,    89,
      88,    53,    55,    57,    59,    60,    65,    63,    64,    62,
      67,    68,    71,    70,    73,    74,    75,     0,    45,     0,
      44,    25,     0,    29,    39,    38,     0,    31,    50,    19,
       0,     0,    30,    47
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
     -59,   -59,   -59,   -59,   -59,   -11,   -59,   188,   -59,   -59,
     -59,   -59,   -59,   128,   -54,   -59,   -28,   -27,   -26,   -59,
     -50,   -59,   108,   112,   113,   -29,     9,    -8,    -1,   -58,
     -59
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_uint8 yydefgoto[] =
{
       0,     2,     6,    11,    12,    30,    20,    31,    32,    93,
      24,    28,    47,    27,    48,    58,    71,    72,    73,   129,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84
};

/* YYTABLE[YYPACT[STATE-NUM]] -- What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule whose
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
static const yytype_uint8 yytable[] =
{
      49,    50,    51,    19,    95,   104,   105,   106,    99,    96,
      98,   122,   102,   123,    34,    86,    15,    46,     7,    16,
     120,     1,    17,   124,    87,   121,   127,     3,    87,    18,
      49,    50,    51,    35,   159,   125,   126,   130,    62,     8,
     101,    63,     9,   107,    64,    86,    65,   107,   128,    34,
       4,   160,    62,   100,    87,    63,    10,    36,    64,   112,
      65,   118,   119,    42,   154,   155,   156,    37,   161,   113,
       5,    67,    68,    69,    13,    70,    15,    42,    94,    16,
     163,    39,    17,   144,   145,    67,    68,    69,   166,    70,
      21,    40,    15,    41,    42,    16,    43,    23,    17,    14,
      44,    22,    45,   167,    29,    25,    49,    50,    51,   168,
     150,   151,   114,   115,    26,   116,   172,    36,   117,   152,
     153,    52,   162,   146,   147,   148,   149,    37,    53,    49,
      50,    51,    54,    55,    56,    36,    57,    59,    38,    60,
      61,    39,    49,    50,    51,    37,    15,    89,    85,    16,
      88,    40,    17,    41,    42,    90,    43,    91,    62,    39,
      44,    63,    45,    92,    64,   108,    65,   109,   110,    40,
      66,    41,    42,    62,    43,   111,    63,   132,    44,    64,
      45,    65,   133,    42,   134,   135,   136,   137,   138,   139,
     140,    67,    68,    69,    62,    70,   157,    63,    42,   169,
      64,   158,    65,   170,   164,   165,    67,    68,    69,    97,
      70,   171,    62,   173,    33,    63,   131,   141,    64,    42,
      65,     0,   142,     0,   143,     0,     0,    67,    68,    69,
       0,    70,     0,     0,     0,     0,     0,    42,     0,     0,
       0,     0,     0,     0,     0,   103,    68,    69,     0,    70
};

static const yytype_int16 yycheck[] =
{
      28,    28,    28,    14,    58,    63,    64,    65,     1,    59,
      60,     5,    62,     7,     6,     4,    30,    28,     1,    33,
      16,    31,    36,    17,    13,    21,     1,    46,    13,    43,
      58,    58,    58,    25,     6,    85,    86,    87,    13,    22,
       1,    16,    25,    32,    19,     4,    21,    32,    23,     6,
       0,    23,    13,    46,    13,    16,    39,     1,    19,     8,
      21,    27,    28,    38,   122,   123,   124,    11,    25,    18,
      11,    46,    47,    48,    25,    50,    30,    38,    22,    33,
     134,    25,    36,   112,   113,    46,    47,    48,   138,    50,
      46,    35,    30,    37,    38,    33,    40,    11,    36,    41,
      44,    46,    46,   157,    42,    13,   134,   134,   134,   159,
     118,   119,     9,    10,    13,    12,   170,     1,    15,   120,
     121,    14,   133,   114,   115,   116,   117,    11,    46,   157,
     157,   157,    23,    23,    46,     1,    25,    13,    22,    13,
      13,    25,   170,   170,   170,    11,    30,    25,    13,    33,
      46,    35,    36,    37,    38,    25,    40,    25,    13,    25,
      44,    16,    46,    24,    19,    25,    21,    20,     3,    35,
      25,    37,    38,    13,    40,    29,    16,    46,    44,    19,
      46,    21,     6,    38,    23,    23,    23,    23,    14,    23,
      23,    46,    47,    48,    13,    50,    23,    16,    38,    46,
      19,    23,    21,    34,    25,    25,    46,    47,    48,    49,
      50,    24,    13,    23,    26,    16,    88,   109,    19,    38,
      21,    -1,   110,    -1,   111,    -1,    -1,    46,    47,    48,
      -1,    50,    -1,    -1,    -1,    -1,    -1,    38,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    46,    47,    48,    -1,    50
};

/* YYSTOS[STATE-NUM] -- The symbol kind of the accessing symbol of
   state STATE-NUM.  */
static const yytype_int8 yystos[] =
{
       0,    31,    53,    46,     0,    11,    54,     1,    22,    25,
      39,    55,    56,    25,    41,    30,    33,    36,    43,    57,
      58,    46,    46,    11,    62,    13,    13,    65,    63,    42,
      57,    59,    60,    59,     6,    25,     1,    11,    22,    25,
      35,    37,    38,    40,    44,    46,    57,    64,    66,    68,
      69,    70,    14,    46,    23,    23,    46,    25,    67,    13,
      13,    13,    13,    16,    19,    21,    25,    46,    47,    48,
      50,    68,    69,    70,    72,    73,    74,    75,    76,    77,
      78,    79,    80,    81,    82,    13,     4,    13,    46,    25,
      25,    25,    24,    61,    22,    66,    72,    49,    72,     1,
      46,     1,    72,    46,    81,    81,    81,    32,    25,    20,
       3,    29,     8,    18,     9,    10,    12,    15,    27,    28,
      16,    21,     5,     7,    17,    72,    72,     1,    23,    71,
      72,    65,    46,     6,    23,    23,    23,    23,    14,    23,
      23,    74,    75,    76,    77,    77,    78,    78,    78,    78,
      79,    79,    80,    80,    81,    81,    81,    23,    23,     6,
      23,    25,    57,    66,    25,    25,    72,    66,    72,    46,
      34,    24,    66,    23
};

/* YYR1[RULE-NUM] -- Symbol kind of the left-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr1[] =
{
       0,    52,    53,    54,    54,    54,    54,    55,    56,    56,
      57,    57,    57,    58,    58,    59,    59,    60,    60,    61,
      61,    62,    63,    63,    63,    64,    65,    65,    66,    66,
      66,    66,    66,    66,    66,    66,    66,    66,    66,    66,
      66,    67,    67,    68,    68,    68,    69,    70,    70,    71,
      71,    72,    72,    73,    73,    74,    74,    75,    75,    76,
      76,    76,    77,    77,    77,    77,    77,    78,    78,    78,
      79,    79,    79,    80,    80,    80,    80,    81,    81,    81,
      81,    82,    82,    82,    82,    82,    82,    82,    82,    82
};

/* YYR2[RULE-NUM] -- Number of symbols on the right-hand side of rule RULE-NUM.  */
static const yytype_int8 yyr2[] =
{
       0,     2,     5,     2,     2,     2,     0,     4,     6,     2,
       1,     1,     1,     5,     5,     1,     0,     3,     4,     4,
       0,     3,     2,     2,     0,     4,     3,     0,     3,     5,
       7,     5,     2,     3,     2,     2,     2,     1,     5,     5,
       2,     2,     0,     3,     4,     4,     3,     7,     4,     1,
       3,     1,     1,     3,     1,     3,     1,     3,     1,     3,
       3,     1,     3,     3,     3,     3,     1,     3,     3,     1,
       3,     3,     1,     3,     3,     3,     1,     2,     2,     2,
       1,     1,     1,     2,     1,     1,     1,     1,     3,     3
};


enum { YYENOMEM = -2 };

#define yyerrok         (yyerrstatus = 0)
#define yyclearin       (yychar = YYEMPTY)

#define YYACCEPT        goto yyacceptlab
#define YYABORT         goto yyabortlab
#define YYERROR         goto yyerrorlab
#define YYNOMEM         goto yyexhaustedlab


#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)                                    \
  do                                                              \
    if (yychar == YYEMPTY)                                        \
      {                                                           \
        yychar = (Token);                                         \
        yylval = (Value);                                         \
        YYPOPSTACK (yylen);                                       \
        yystate = *yyssp;                                         \
        goto yybackup;                                            \
      }                                                           \
    else                                                          \
      {                                                           \
        yyerror (YY_("syntax error: cannot back up")); \
        YYERROR;                                                  \
      }                                                           \
  while (0)

/* Backward compatibility with an undocumented macro.
   Use YYerror or YYUNDEF. */
#define YYERRCODE YYUNDEF


/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)                        \
do {                                            \
  if (yydebug)                                  \
    YYFPRINTF Args;                             \
} while (0)




# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)                    \
do {                                                                      \
  if (yydebug)                                                            \
    {                                                                     \
      YYFPRINTF (stderr, "%s ", Title);                                   \
      yy_symbol_print (stderr,                                            \
                  Kind, Value); \
      YYFPRINTF (stderr, "\n");                                           \
    }                                                                     \
} while (0)


/*-----------------------------------.
| Print this symbol's value on YYO.  |
`-----------------------------------*/

static void
yy_symbol_value_print (FILE *yyo,
                       yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  FILE *yyoutput = yyo;
  YY_USE (yyoutput);
  if (!yyvaluep)
    return;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/*---------------------------.
| Print this symbol on YYO.  |
`---------------------------*/

static void
yy_symbol_print (FILE *yyo,
                 yysymbol_kind_t yykind, YYSTYPE const * const yyvaluep)
{
  YYFPRINTF (yyo, "%s %s (",
             yykind < YYNTOKENS ? "token" : "nterm", yysymbol_name (yykind));

  yy_symbol_value_print (yyo, yykind, yyvaluep);
  YYFPRINTF (yyo, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

static void
yy_stack_print (yy_state_t *yybottom, yy_state_t *yytop)
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)                            \
do {                                                            \
  if (yydebug)                                                  \
    yy_stack_print ((Bottom), (Top));                           \
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

static void
yy_reduce_print (yy_state_t *yyssp, YYSTYPE *yyvsp,
                 int yyrule)
{
  int yylno = yyrline[yyrule];
  int yynrhs = yyr2[yyrule];
  int yyi;
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %d):\n",
             yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr,
                       YY_ACCESSING_SYMBOL (+yyssp[yyi + 1 - yynrhs]),
                       &yyvsp[(yyi + 1) - (yynrhs)]);
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)          \
do {                                    \
  if (yydebug)                          \
    yy_reduce_print (yyssp, yyvsp, Rule); \
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args) ((void) 0)
# define YY_SYMBOL_PRINT(Title, Kind, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif






/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

static void
yydestruct (const char *yymsg,
            yysymbol_kind_t yykind, YYSTYPE *yyvaluep)
{
  YY_USE (yyvaluep);
  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yykind, yyvaluep, yylocationp);

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  YY_USE (yykind);
  YY_IGNORE_MAYBE_UNINITIALIZED_END
}


/* Lookahead token kind.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;
/* Number of syntax errors so far.  */
int yynerrs;




/*----------.
| yyparse.  |
`----------*/

int
yyparse (void)
{
    yy_state_fast_t yystate = 0;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus = 0;

    /* Refer to the stacks through separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* Their size.  */
    YYPTRDIFF_T yystacksize = YYINITDEPTH;

    /* The state stack: array, bottom, top.  */
    yy_state_t yyssa[YYINITDEPTH];
    yy_state_t *yyss = yyssa;
    yy_state_t *yyssp = yyss;

    /* The semantic value stack: array, bottom, top.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs = yyvsa;
    YYSTYPE *yyvsp = yyvs;

  int yyn;
  /* The return value of yyparse.  */
  int yyresult;
  /* Lookahead symbol kind.  */
  yysymbol_kind_t yytoken = YYSYMBOL_YYEMPTY;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yychar = YYEMPTY; /* Cause a token to be read.  */

  goto yysetstate;


/*------------------------------------------------------------.
| yynewstate -- push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;


/*--------------------------------------------------------------------.
| yysetstate -- set current state (the top of the stack) to yystate.  |
`--------------------------------------------------------------------*/
yysetstate:
  YYDPRINTF ((stderr, "Entering state %d\n", yystate));
  YY_ASSERT (0 <= yystate && yystate < YYNSTATES);
  YY_IGNORE_USELESS_CAST_BEGIN
  *yyssp = YY_CAST (yy_state_t, yystate);
  YY_IGNORE_USELESS_CAST_END
  YY_STACK_PRINT (yyss, yyssp);

  if (yyss + yystacksize - 1 <= yyssp)
#if !defined yyoverflow && !defined YYSTACK_RELOCATE
    YYNOMEM;
#else
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYPTRDIFF_T yysize = yyssp - yyss + 1;

# if defined yyoverflow
      {
        /* Give user a chance to reallocate the stack.  Use copies of
           these so that the &'s don't force the real ones into
           memory.  */
        yy_state_t *yyss1 = yyss;
        YYSTYPE *yyvs1 = yyvs;

        /* Each stack pointer address is followed by the size of the
           data in use in that stack, in bytes.  This used to be a
           conditional around just the two extra args, but that might
           be undefined if yyoverflow is a macro.  */
        yyoverflow (YY_("memory exhausted"),
                    &yyss1, yysize * YYSIZEOF (*yyssp),
                    &yyvs1, yysize * YYSIZEOF (*yyvsp),
                    &yystacksize);
        yyss = yyss1;
        yyvs = yyvs1;
      }
# else /* defined YYSTACK_RELOCATE */
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
        YYNOMEM;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
        yystacksize = YYMAXDEPTH;

      {
        yy_state_t *yyss1 = yyss;
        union yyalloc *yyptr =
          YY_CAST (union yyalloc *,
                   YYSTACK_ALLOC (YY_CAST (YYSIZE_T, YYSTACK_BYTES (yystacksize))));
        if (! yyptr)
          YYNOMEM;
        YYSTACK_RELOCATE (yyss_alloc, yyss);
        YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
        if (yyss1 != yyssa)
          YYSTACK_FREE (yyss1);
      }
# endif

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YY_IGNORE_USELESS_CAST_BEGIN
      YYDPRINTF ((stderr, "Stack size increased to %ld\n",
                  YY_CAST (long, yystacksize)));
      YY_IGNORE_USELESS_CAST_END

      if (yyss + yystacksize - 1 <= yyssp)
        YYABORT;
    }
#endif /* !defined yyoverflow && !defined YYSTACK_RELOCATE */


  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;


/*-----------.
| yybackup.  |
`-----------*/
yybackup:
  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either empty, or end-of-input, or a valid lookahead.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token\n"));
      yychar = yylex ();
    }

  if (yychar <= YYEOF)
    {
      yychar = YYEOF;
      yytoken = YYSYMBOL_YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else if (yychar == YYerror)
    {
      /* The scanner already issued an error message, process directly
         to error recovery.  But do not keep the error token as
         lookahead, it is too special and may lead us to an endless
         loop in error recovery. */
      yychar = YYUNDEF;
      yytoken = YYSYMBOL_YYerror;
      goto yyerrlab1;
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);
  yystate = yyn;
  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END

  /* Discard the shifted token.  */
  yychar = YYEMPTY;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     '$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
  case 2: /* Program: CLASS IDENTIFIER LBRACE ProgramDecls RBRACE  */
#line 45 "jucompiler.y"
                                                     { 
            (yyval.node) = newnode(Program, NULL);
            struct node *id = newnode(Identifier, (yyvsp[-3].info).id);
            id->line = (yyvsp[-3].info).line; id->col = (yyvsp[-3].info).col;
            addchild((yyval.node), id);
            if ((yyvsp[-1].node) != NULL) {
                struct node_list *child = (yyvsp[-1].node)->children;
                while (child != NULL) {
                    addchild((yyval.node), child->node);
                    child = child->next;
                }
                free_list_and_node((yyvsp[-1].node));
            }
            ast = (yyval.node);
        }
#line 1465 "y.tab.c"
    break;

  case 3: /* ProgramDecls: ProgramDecls MethodDecl  */
#line 62 "jucompiler.y"
                                      { 
                (yyval.node) = (yyvsp[-1].node);
                if ((yyval.node) == NULL) (yyval.node) = newnode(Program, NULL);
                if ((yyvsp[0].node) != NULL) addchild((yyval.node), (yyvsp[0].node));
            }
#line 1475 "y.tab.c"
    break;

  case 4: /* ProgramDecls: ProgramDecls FieldDecl  */
#line 67 "jucompiler.y"
                                     { 
                (yyval.node) = (yyvsp[-1].node);
                if ((yyval.node) == NULL) (yyval.node) = newnode(Program, NULL); 
                if ((yyvsp[0].node) != NULL) {
                    struct node_list *child = (yyvsp[0].node)->children;
                    while (child != NULL) {
                        addchild((yyval.node), child->node);
                        child = child->next;
                    }
                    free_list_and_node((yyvsp[0].node));
                }
            }
#line 1492 "y.tab.c"
    break;

  case 5: /* ProgramDecls: ProgramDecls SEMICOLON  */
#line 79 "jucompiler.y"
                                     { (yyval.node) = (yyvsp[-1].node); }
#line 1498 "y.tab.c"
    break;

  case 6: /* ProgramDecls: %empty  */
#line 80 "jucompiler.y"
              { (yyval.node) = NULL; }
#line 1504 "y.tab.c"
    break;

  case 7: /* MethodDecl: PUBLIC STATIC MethodHeader MethodBody  */
#line 83 "jucompiler.y"
                                                  { 
                (yyval.node) = newnode(MethodDecl, NULL);
                addchild((yyval.node), (yyvsp[-1].node));
                addchild((yyval.node), (yyvsp[0].node));
            }
#line 1514 "y.tab.c"
    break;

  case 8: /* FieldDecl: PUBLIC STATIC Type IDENTIFIER IdList SEMICOLON  */
#line 90 "jucompiler.y"
                                                          { 
                (yyval.node) = newnode(Program, NULL);
                struct node *first = newnode(FieldDecl, NULL);
                addchild(first, newnode((yyvsp[-3].node)->category, NULL));
                struct node *id = newnode(Identifier, (yyvsp[-2].info).id);
                id->line = (yyvsp[-2].info).line;
                id->col = (yyvsp[-2].info).col;
                addchild(first, id);
                addchild((yyval.node), first);
                if ((yyvsp[-1].node) != NULL) {
                    struct node_list *child = (yyvsp[-1].node)->children;
                    while (child != NULL) {
                        struct node *next_field = newnode(FieldDecl, NULL);
                        addchild(next_field, newnode((yyvsp[-3].node)->category, NULL));
                        addchild(next_field, child->node);
                        addchild((yyval.node), next_field);
                        child = child->next;
                    }
                    free_list_and_node((yyvsp[-1].node));
                }
            }
#line 1540 "y.tab.c"
    break;

  case 9: /* FieldDecl: error SEMICOLON  */
#line 111 "jucompiler.y"
                           { (yyval.node) = NULL; }
#line 1546 "y.tab.c"
    break;

  case 10: /* Type: BOOL  */
#line 114 "jucompiler.y"
           { (yyval.node) = newnode(Bool, NULL); }
#line 1552 "y.tab.c"
    break;

  case 11: /* Type: INT  */
#line 115 "jucompiler.y"
          { (yyval.node) = newnode(Int, NULL); }
#line 1558 "y.tab.c"
    break;

  case 12: /* Type: DOUBLE  */
#line 116 "jucompiler.y"
             { (yyval.node) = newnode(Double, NULL); }
#line 1564 "y.tab.c"
    break;

  case 13: /* MethodHeader: Type IDENTIFIER LPAR MethodParams RPAR  */
#line 119 "jucompiler.y"
                                                     { 
                (yyval.node) = newnode(MethodHeader, NULL);
                addchild((yyval.node), (yyvsp[-4].node));
                struct node *id = newnode(Identifier, (yyvsp[-3].info).id);
                id->line = (yyvsp[-3].info).line; id->col = (yyvsp[-3].info).col;
                addchild((yyval.node), id);
                addchild((yyval.node), (yyvsp[-1].node));
            }
#line 1577 "y.tab.c"
    break;

  case 14: /* MethodHeader: VOID IDENTIFIER LPAR MethodParams RPAR  */
#line 127 "jucompiler.y"
                                                     { 
                (yyval.node) = newnode(MethodHeader, NULL);
                addchild((yyval.node), newnode(Void, NULL));
                struct node *id = newnode(Identifier, (yyvsp[-3].info).id);
                id->line = (yyvsp[-3].info).line; id->col = (yyvsp[-3].info).col;
                addchild((yyval.node), id);
                addchild((yyval.node), (yyvsp[-1].node));
            }
#line 1590 "y.tab.c"
    break;

  case 15: /* MethodParams: FormalParams  */
#line 137 "jucompiler.y"
                           { 
                (yyval.node) = newnode(MethodParams, NULL);
                if ((yyvsp[0].node) != NULL) {
                    struct node_list *child = (yyvsp[0].node)->children;
                    while (child != NULL) {
                        addchild((yyval.node), child->node);
                        child = child->next;
                    }
                    free_list_and_node((yyvsp[0].node));
                }
            }
#line 1606 "y.tab.c"
    break;

  case 16: /* MethodParams: %empty  */
#line 148 "jucompiler.y"
              { (yyval.node) = newnode(MethodParams, NULL); }
#line 1612 "y.tab.c"
    break;

  case 17: /* FormalParams: Type IDENTIFIER FormalParamsList  */
#line 151 "jucompiler.y"
                                               { 
                (yyval.node) = newnode(Program, NULL);
                struct node *p1 = newnode(ParamDecl, NULL);
                addchild(p1, (yyvsp[-2].node));
                struct node *id = newnode(Identifier, (yyvsp[-1].info).id);
                id->line = (yyvsp[-1].info).line; id->col = (yyvsp[-1].info).col;
                addchild(p1, id);
                addchild((yyval.node), p1);
                if ((yyvsp[0].node) != NULL) {
                    struct node_list *child = (yyvsp[0].node)->children;
                    while (child != NULL) {
                        addchild((yyval.node), child->node);
                        child = child->next;
                    }
                    free_list_and_node((yyvsp[0].node));
                }
            }
#line 1634 "y.tab.c"
    break;

  case 18: /* FormalParams: STRING LSQ RSQ IDENTIFIER  */
#line 168 "jucompiler.y"
                                        { 
                (yyval.node) = newnode(Program, NULL);
                struct node *p1 = newnode(ParamDecl, NULL);
                addchild(p1, newnode(StringArray, NULL));
                struct node *id = newnode(Identifier, (yyvsp[0].info).id);
                id->line = (yyvsp[0].info).line;
                id->col = (yyvsp[0].info).col;
                addchild(p1, id);
                addchild((yyval.node), p1);
            }
#line 1649 "y.tab.c"
    break;

  case 19: /* FormalParamsList: FormalParamsList COMMA Type IDENTIFIER  */
#line 180 "jucompiler.y"
                                                         { 
                    (yyval.node) = (yyvsp[-3].node);
                    if ((yyval.node) == NULL) (yyval.node) = newnode(Program, NULL);
                    struct node *p = newnode(ParamDecl, NULL);
                    addchild(p, (yyvsp[-1].node));
                    struct node *id = newnode(Identifier, (yyvsp[0].info).id);
                    id->line = (yyvsp[0].info).line; id->col = (yyvsp[0].info).col;
                    addchild(p, id);
                    addchild((yyval.node), p);
                }
#line 1664 "y.tab.c"
    break;

  case 20: /* FormalParamsList: %empty  */
#line 190 "jucompiler.y"
                  { (yyval.node) = NULL; }
#line 1670 "y.tab.c"
    break;

  case 21: /* MethodBody: LBRACE MethodBodyDecls RBRACE  */
#line 193 "jucompiler.y"
                                          { 
                (yyval.node) = newnode(MethodBody, NULL);
                if ((yyvsp[-1].node) != NULL) {
                    struct node_list *child = (yyvsp[-1].node)->children;
                    while (child != NULL) {
                        addchild((yyval.node), child->node);
                        child = child->next;
                    }
                    free_list_and_node((yyvsp[-1].node));
                }
            }
#line 1686 "y.tab.c"
    break;

  case 22: /* MethodBodyDecls: MethodBodyDecls Statement  */
#line 206 "jucompiler.y"
                                           { 
                    (yyval.node) = (yyvsp[-1].node);
                    if ((yyval.node) == NULL) (yyval.node) = newnode(Program, NULL);
                    if ((yyvsp[0].node) != NULL) addchild((yyval.node), (yyvsp[0].node));
               }
#line 1696 "y.tab.c"
    break;

  case 23: /* MethodBodyDecls: MethodBodyDecls VarDecl  */
#line 211 "jucompiler.y"
                                         { 
                    (yyval.node) = (yyvsp[-1].node);
                    if ((yyval.node) == NULL) (yyval.node) = newnode(Program, NULL);
                    if ((yyvsp[0].node) != NULL) {
                        struct node_list *child = (yyvsp[0].node)->children;
                        while (child != NULL) {
                            addchild((yyval.node), child->node);
                            child = child->next;
                        }
                        free_list_and_node((yyvsp[0].node));
                    }
                }
#line 1713 "y.tab.c"
    break;

  case 24: /* MethodBodyDecls: %empty  */
#line 223 "jucompiler.y"
                 { (yyval.node) = NULL; }
#line 1719 "y.tab.c"
    break;

  case 25: /* VarDecl: Type IDENTIFIER IdList SEMICOLON  */
#line 226 "jucompiler.y"
                                          { 
            (yyval.node) = newnode(Program, NULL);
            struct node *first = newnode(VarDecl, NULL);
            addchild(first, newnode((yyvsp[-3].node)->category, NULL));
            struct node *id = newnode(Identifier, (yyvsp[-2].info).id);
            id->line = (yyvsp[-2].info).line;
            id->col = (yyvsp[-2].info).col;
            addchild(first, id);
            addchild((yyval.node), first);
            if ((yyvsp[-1].node) != NULL) {
                struct node_list *child = (yyvsp[-1].node)->children;
                while (child != NULL) {
                    struct node *next_var = newnode(VarDecl, NULL);
                    addchild(next_var, newnode((yyvsp[-3].node)->category, NULL));
                    addchild(next_var, child->node);
                    addchild((yyval.node), next_var);
                    child = child->next;
                }
                free_list_and_node((yyvsp[-1].node));
            }
        }
#line 1745 "y.tab.c"
    break;

  case 26: /* IdList: IdList COMMA IDENTIFIER  */
#line 249 "jucompiler.y"
                                { 
            (yyval.node) = (yyvsp[-2].node);
            if ((yyval.node) == NULL) (yyval.node) = newnode(Program, NULL);
            struct node *id = newnode(Identifier, (yyvsp[0].info).id);
            id->line = (yyvsp[0].info).line; id->col = (yyvsp[0].info).col;
            addchild((yyval.node), id);
        }
#line 1757 "y.tab.c"
    break;

  case 27: /* IdList: %empty  */
#line 256 "jucompiler.y"
        { (yyval.node) = NULL; }
#line 1763 "y.tab.c"
    break;

  case 28: /* Statement: LBRACE StatementList RBRACE  */
#line 260 "jucompiler.y"
         { 
             int count = 0;
             if ((yyvsp[-1].node) != NULL) {
                 struct node_list *child = (yyvsp[-1].node)->children;
                 while (child != NULL) {
                     count++;
                     child = child->next;
                 }
             }

             if (count == 0) {
                 (yyval.node) = NULL;
                 if ((yyvsp[-1].node)) free_list_and_node((yyvsp[-1].node));
             } else if (count == 1) {
                 (yyval.node) = (yyvsp[-1].node)->children->node;
                 free_list_and_node((yyvsp[-1].node));
             } else {
                 (yyval.node) = newnode(Block, NULL);
                 struct node_list *child = (yyvsp[-1].node)->children;
                 while (child != NULL) {
                     addchild((yyval.node), child->node);
                     child = child->next;
                 }
                 free_list_and_node((yyvsp[-1].node));
             }
         }
#line 1794 "y.tab.c"
    break;

  case 29: /* Statement: IF LPAR Expr RPAR Statement  */
#line 287 "jucompiler.y"
         { 
             (yyval.node) = newnode(If, NULL);
             addchild((yyval.node), (yyvsp[-2].node));
             addchild((yyval.node), (yyvsp[0].node) != NULL ? (yyvsp[0].node) : newnode(Block, NULL));
             addchild((yyval.node), newnode(Block, NULL));
         }
#line 1805 "y.tab.c"
    break;

  case 30: /* Statement: IF LPAR Expr RPAR Statement ELSE Statement  */
#line 294 "jucompiler.y"
         { 
             (yyval.node) = newnode(If, NULL);
             addchild((yyval.node), (yyvsp[-4].node));
             addchild((yyval.node), (yyvsp[-2].node) != NULL ? (yyvsp[-2].node) : newnode(Block, NULL));
             addchild((yyval.node), (yyvsp[0].node) != NULL ? (yyvsp[0].node) : newnode(Block, NULL));
         }
#line 1816 "y.tab.c"
    break;

  case 31: /* Statement: WHILE LPAR Expr RPAR Statement  */
#line 301 "jucompiler.y"
         { 
             (yyval.node) = newnode(While, NULL);
             addchild((yyval.node), (yyvsp[-2].node));
             addchild((yyval.node), (yyvsp[0].node) != NULL ? (yyvsp[0].node) : newnode(Block, NULL));
         }
#line 1826 "y.tab.c"
    break;

  case 32: /* Statement: RETURN SEMICOLON  */
#line 307 "jucompiler.y"
         { 
             (yyval.node) = newnode(Return, NULL);
             (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col;
         }
#line 1835 "y.tab.c"
    break;

  case 33: /* Statement: RETURN Expr SEMICOLON  */
#line 312 "jucompiler.y"
         { 
             (yyval.node) = newnode(Return, NULL);
             (yyval.node)->line = (yyvsp[-2].info).line; (yyval.node)->col = (yyvsp[-2].info).col;
             addchild((yyval.node), (yyvsp[-1].node));
         }
#line 1845 "y.tab.c"
    break;

  case 34: /* Statement: MethodInvocation SEMICOLON  */
#line 317 "jucompiler.y"
                                      { (yyval.node) = (yyvsp[-1].node); }
#line 1851 "y.tab.c"
    break;

  case 35: /* Statement: Assignment SEMICOLON  */
#line 318 "jucompiler.y"
                                { (yyval.node) = (yyvsp[-1].node); }
#line 1857 "y.tab.c"
    break;

  case 36: /* Statement: ParseArgs SEMICOLON  */
#line 319 "jucompiler.y"
                               { (yyval.node) = (yyvsp[-1].node); }
#line 1863 "y.tab.c"
    break;

  case 37: /* Statement: SEMICOLON  */
#line 320 "jucompiler.y"
                     { (yyval.node) = NULL; }
#line 1869 "y.tab.c"
    break;

  case 38: /* Statement: PRINT LPAR Expr RPAR SEMICOLON  */
#line 322 "jucompiler.y"
         { 
             (yyval.node) = newnode(Print, NULL);
             addchild((yyval.node), (yyvsp[-2].node));
         }
#line 1878 "y.tab.c"
    break;

  case 39: /* Statement: PRINT LPAR STRLIT RPAR SEMICOLON  */
#line 327 "jucompiler.y"
        { 
            (yyval.node) = newnode(Print, NULL);
            struct node *str = newnode(StrLit, (yyvsp[-2].info).id);
            str->line = (yyvsp[-2].info).line; str->col = (yyvsp[-2].info).col;
            addchild((yyval.node), str);
        }
#line 1889 "y.tab.c"
    break;

  case 40: /* Statement: error SEMICOLON  */
#line 333 "jucompiler.y"
                           { (yyval.node) = NULL; }
#line 1895 "y.tab.c"
    break;

  case 41: /* StatementList: StatementList Statement  */
#line 337 "jucompiler.y"
             { 
                 (yyval.node) = (yyvsp[-1].node);
                 if ((yyval.node) == NULL) (yyval.node) = newnode(Program, NULL); 
                 if ((yyvsp[0].node) != NULL) addchild((yyval.node), (yyvsp[0].node));
             }
#line 1905 "y.tab.c"
    break;

  case 42: /* StatementList: %empty  */
#line 342 "jucompiler.y"
               { (yyval.node) = newnode(Program, NULL); }
#line 1911 "y.tab.c"
    break;

  case 43: /* MethodInvocation: IDENTIFIER LPAR RPAR  */
#line 346 "jucompiler.y"
                { 
                    (yyval.node) = newnode(Call, NULL);
                    (yyval.node)->line = (yyvsp[-2].info).line; (yyval.node)->col = (yyvsp[-2].info).col;
                    struct node *id = newnode(Identifier, (yyvsp[-2].info).id);
                    id->line = (yyvsp[-2].info).line; id->col = (yyvsp[-2].info).col;
                    id->is_expr = 1;
                    addchild((yyval.node), id);
                }
#line 1924 "y.tab.c"
    break;

  case 44: /* MethodInvocation: IDENTIFIER LPAR ExprList RPAR  */
#line 355 "jucompiler.y"
                { 
                    (yyval.node) = newnode(Call, NULL);
                    (yyval.node)->line = (yyvsp[-3].info).line; (yyval.node)->col = (yyvsp[-3].info).col;
                    struct node *id = newnode(Identifier, (yyvsp[-3].info).id);
                    id->line = (yyvsp[-3].info).line; id->col = (yyvsp[-3].info).col;
                    id->is_expr = 1;
                    addchild((yyval.node), id);
                    struct node_list *child = (yyvsp[-1].node)->children;
                    while (child != NULL) {
                        addchild((yyval.node), child->node);
                        child = child->next;
                    }
                    free_list_and_node((yyvsp[-1].node));
                }
#line 1943 "y.tab.c"
    break;

  case 45: /* MethodInvocation: IDENTIFIER LPAR error RPAR  */
#line 369 "jucompiler.y"
                                             { (yyval.node) = NULL; }
#line 1949 "y.tab.c"
    break;

  case 46: /* Assignment: IDENTIFIER ASSIGN Expr  */
#line 373 "jucompiler.y"
          { 
              (yyval.node) = newnode(Assign, NULL);
              (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col;
              struct node *id = newnode(Identifier, (yyvsp[-2].info).id);
              id->line = (yyvsp[-2].info).line; id->col = (yyvsp[-2].info).col;
              id->is_expr = 1;
              addchild((yyval.node), id); addchild((yyval.node), (yyvsp[0].node));
          }
#line 1962 "y.tab.c"
    break;

  case 47: /* ParseArgs: PARSEINT LPAR IDENTIFIER LSQ Expr RSQ RPAR  */
#line 384 "jucompiler.y"
         { 
             (yyval.node) = newnode(ParseArgs, NULL);
             (yyval.node)->line = (yyvsp[-6].info).line; (yyval.node)->col = (yyvsp[-6].info).col;
             struct node *id = newnode(Identifier, (yyvsp[-4].info).id);
             id->line = (yyvsp[-4].info).line; id->col = (yyvsp[-4].info).col;
             id->is_expr = 1;
             addchild((yyval.node), id);
             addchild((yyval.node), (yyvsp[-2].node));
         }
#line 1976 "y.tab.c"
    break;

  case 48: /* ParseArgs: PARSEINT LPAR error RPAR  */
#line 393 "jucompiler.y"
                                    { (yyval.node) = NULL; }
#line 1982 "y.tab.c"
    break;

  case 49: /* ExprList: Expr  */
#line 397 "jucompiler.y"
        { 
            (yyval.node) = newnode(Program, NULL);
            addchild((yyval.node), (yyvsp[0].node));
        }
#line 1991 "y.tab.c"
    break;

  case 50: /* ExprList: ExprList COMMA Expr  */
#line 402 "jucompiler.y"
        { 
            (yyval.node) = (yyvsp[-2].node);
            addchild((yyval.node), (yyvsp[0].node));
        }
#line 2000 "y.tab.c"
    break;

  case 51: /* Expr: Assignment  */
#line 408 "jucompiler.y"
                 { (yyval.node) = (yyvsp[0].node); }
#line 2006 "y.tab.c"
    break;

  case 52: /* Expr: ExprOr  */
#line 409 "jucompiler.y"
                 { (yyval.node) = (yyvsp[0].node); }
#line 2012 "y.tab.c"
    break;

  case 53: /* ExprOr: ExprOr OR ExprAnd  */
#line 413 "jucompiler.y"
        { (yyval.node) = newnode(Or, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2018 "y.tab.c"
    break;

  case 54: /* ExprOr: ExprAnd  */
#line 414 "jucompiler.y"
                { (yyval.node) = (yyvsp[0].node); }
#line 2024 "y.tab.c"
    break;

  case 55: /* ExprAnd: ExprAnd AND ExprXor  */
#line 418 "jucompiler.y"
        { (yyval.node) = newnode(And, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2030 "y.tab.c"
    break;

  case 56: /* ExprAnd: ExprXor  */
#line 419 "jucompiler.y"
                 { (yyval.node) = (yyvsp[0].node); }
#line 2036 "y.tab.c"
    break;

  case 57: /* ExprXor: ExprXor XOR ExprEq  */
#line 423 "jucompiler.y"
        { (yyval.node) = newnode(Xor, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2042 "y.tab.c"
    break;

  case 58: /* ExprXor: ExprEq  */
#line 424 "jucompiler.y"
                { (yyval.node) = (yyvsp[0].node); }
#line 2048 "y.tab.c"
    break;

  case 59: /* ExprEq: ExprEq EQ ExprRel  */
#line 428 "jucompiler.y"
        { (yyval.node) = newnode(Eq, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2054 "y.tab.c"
    break;

  case 60: /* ExprEq: ExprEq NE ExprRel  */
#line 430 "jucompiler.y"
        { (yyval.node) = newnode(Ne, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2060 "y.tab.c"
    break;

  case 61: /* ExprEq: ExprRel  */
#line 431 "jucompiler.y"
                { (yyval.node) = (yyvsp[0].node); }
#line 2066 "y.tab.c"
    break;

  case 62: /* ExprRel: ExprRel LT ExprShift  */
#line 435 "jucompiler.y"
        { (yyval.node) = newnode(Lt, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2072 "y.tab.c"
    break;

  case 63: /* ExprRel: ExprRel GT ExprShift  */
#line 437 "jucompiler.y"
        { (yyval.node) = newnode(Gt, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2078 "y.tab.c"
    break;

  case 64: /* ExprRel: ExprRel LE ExprShift  */
#line 439 "jucompiler.y"
        { (yyval.node) = newnode(Le, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2084 "y.tab.c"
    break;

  case 65: /* ExprRel: ExprRel GE ExprShift  */
#line 441 "jucompiler.y"
        { (yyval.node) = newnode(Ge, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2090 "y.tab.c"
    break;

  case 66: /* ExprRel: ExprShift  */
#line 442 "jucompiler.y"
                   { (yyval.node) = (yyvsp[0].node); }
#line 2096 "y.tab.c"
    break;

  case 67: /* ExprShift: ExprShift LSHIFT ExprAdd  */
#line 446 "jucompiler.y"
           { (yyval.node) = newnode(Lshift, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2102 "y.tab.c"
    break;

  case 68: /* ExprShift: ExprShift RSHIFT ExprAdd  */
#line 448 "jucompiler.y"
           { (yyval.node) = newnode(Rshift, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2108 "y.tab.c"
    break;

  case 69: /* ExprShift: ExprAdd  */
#line 449 "jucompiler.y"
                   { (yyval.node) = (yyvsp[0].node); }
#line 2114 "y.tab.c"
    break;

  case 70: /* ExprAdd: ExprAdd PLUS ExprMult  */
#line 453 "jucompiler.y"
         { (yyval.node) = newnode(Add, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2120 "y.tab.c"
    break;

  case 71: /* ExprAdd: ExprAdd MINUS ExprMult  */
#line 455 "jucompiler.y"
         { (yyval.node) = newnode(Sub, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2126 "y.tab.c"
    break;

  case 72: /* ExprAdd: ExprMult  */
#line 456 "jucompiler.y"
                  { (yyval.node) = (yyvsp[0].node); }
#line 2132 "y.tab.c"
    break;

  case 73: /* ExprMult: ExprMult STAR ExprUnary  */
#line 460 "jucompiler.y"
          { (yyval.node) = newnode(Mul, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2138 "y.tab.c"
    break;

  case 74: /* ExprMult: ExprMult DIV ExprUnary  */
#line 462 "jucompiler.y"
          { (yyval.node) = newnode(Div, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2144 "y.tab.c"
    break;

  case 75: /* ExprMult: ExprMult MOD ExprUnary  */
#line 464 "jucompiler.y"
          { (yyval.node) = newnode(Mod, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[-2].node)); addchild((yyval.node), (yyvsp[0].node)); }
#line 2150 "y.tab.c"
    break;

  case 76: /* ExprMult: ExprUnary  */
#line 465 "jucompiler.y"
                    { (yyval.node) = (yyvsp[0].node); }
#line 2156 "y.tab.c"
    break;

  case 77: /* ExprUnary: PLUS ExprUnary  */
#line 468 "jucompiler.y"
                           { (yyval.node) = newnode(Plus, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[0].node)); }
#line 2162 "y.tab.c"
    break;

  case 78: /* ExprUnary: MINUS ExprUnary  */
#line 469 "jucompiler.y"
                           { (yyval.node) = newnode(Minus, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[0].node)); }
#line 2168 "y.tab.c"
    break;

  case 79: /* ExprUnary: NOT ExprUnary  */
#line 470 "jucompiler.y"
                           { (yyval.node) = newnode(Not, NULL); (yyval.node)->line = (yyvsp[-1].info).line; (yyval.node)->col = (yyvsp[-1].info).col; addchild((yyval.node), (yyvsp[0].node)); }
#line 2174 "y.tab.c"
    break;

  case 80: /* ExprUnary: ExprPostfix  */
#line 471 "jucompiler.y"
                           { (yyval.node) = (yyvsp[0].node); }
#line 2180 "y.tab.c"
    break;

  case 81: /* ExprPostfix: MethodInvocation  */
#line 474 "jucompiler.y"
                              { (yyval.node) = (yyvsp[0].node); }
#line 2186 "y.tab.c"
    break;

  case 82: /* ExprPostfix: ParseArgs  */
#line 475 "jucompiler.y"
                       { (yyval.node) = (yyvsp[0].node); }
#line 2192 "y.tab.c"
    break;

  case 83: /* ExprPostfix: IDENTIFIER DOTLENGTH  */
#line 477 "jucompiler.y"
             { 
                 (yyval.node) = newnode(Length, NULL);
                 (yyval.node)->line = (yyvsp[0].info).line; (yyval.node)->col = (yyvsp[0].info).col;
                 struct node *id = newnode(Identifier, (yyvsp[-1].info).id);
                 id->line = (yyvsp[-1].info).line; id->col = (yyvsp[-1].info).col;
                 id->is_expr = 1;
                 addchild((yyval.node), id); 
             }
#line 2205 "y.tab.c"
    break;

  case 84: /* ExprPostfix: IDENTIFIER  */
#line 485 "jucompiler.y"
                        { (yyval.node) = newnode(Identifier, (yyvsp[0].info).id); (yyval.node)->line = (yyvsp[0].info).line; (yyval.node)->col = (yyvsp[0].info).col; (yyval.node)->is_expr = 1; }
#line 2211 "y.tab.c"
    break;

  case 85: /* ExprPostfix: NATURAL  */
#line 486 "jucompiler.y"
                     { (yyval.node) = newnode(Natural, (yyvsp[0].info).id); (yyval.node)->line = (yyvsp[0].info).line; (yyval.node)->col = (yyvsp[0].info).col; (yyval.node)->is_expr = 1; }
#line 2217 "y.tab.c"
    break;

  case 86: /* ExprPostfix: DECIMAL  */
#line 487 "jucompiler.y"
                     { (yyval.node) = newnode(Decimal, (yyvsp[0].info).id); (yyval.node)->line = (yyvsp[0].info).line; (yyval.node)->col = (yyvsp[0].info).col; (yyval.node)->is_expr = 1; }
#line 2223 "y.tab.c"
    break;

  case 87: /* ExprPostfix: BOOLLIT  */
#line 488 "jucompiler.y"
                     { (yyval.node) = newnode(BoolLit, (yyvsp[0].info).id); (yyval.node)->line = (yyvsp[0].info).line; (yyval.node)->col = (yyvsp[0].info).col; (yyval.node)->is_expr = 1; }
#line 2229 "y.tab.c"
    break;

  case 88: /* ExprPostfix: LPAR Expr RPAR  */
#line 489 "jucompiler.y"
                            { (yyval.node) = (yyvsp[-1].node); }
#line 2235 "y.tab.c"
    break;

  case 89: /* ExprPostfix: LPAR error RPAR  */
#line 490 "jucompiler.y"
                             { (yyval.node) = NULL; }
#line 2241 "y.tab.c"
    break;


#line 2245 "y.tab.c"

      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", YY_CAST (yysymbol_kind_t, yyr1[yyn]), &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;

  *++yyvsp = yyval;

  /* Now 'shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */
  {
    const int yylhs = yyr1[yyn] - YYNTOKENS;
    const int yyi = yypgoto[yylhs] + *yyssp;
    yystate = (0 <= yyi && yyi <= YYLAST && yycheck[yyi] == *yyssp
               ? yytable[yyi]
               : yydefgoto[yylhs]);
  }

  goto yynewstate;


/*--------------------------------------.
| yyerrlab -- here on detecting error.  |
`--------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYSYMBOL_YYEMPTY : YYTRANSLATE (yychar);
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
      yyerror (YY_("syntax error"));
    }

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
         error, discard it.  */

      if (yychar <= YYEOF)
        {
          /* Return failure if at end of input.  */
          if (yychar == YYEOF)
            YYABORT;
        }
      else
        {
          yydestruct ("Error: discarding",
                      yytoken, &yylval);
          yychar = YYEMPTY;
        }
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:
  /* Pacify compilers when the user code never invokes YYERROR and the
     label yyerrorlab therefore never appears in user code.  */
  if (0)
    YYERROR;
  ++yynerrs;

  /* Do not reclaim the symbols of the rule whose action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;      /* Each real token shifted decrements this.  */

  /* Pop stack until we find a state that shifts the error token.  */
  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
        {
          yyn += YYSYMBOL_YYerror;
          if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYSYMBOL_YYerror)
            {
              yyn = yytable[yyn];
              if (0 < yyn)
                break;
            }
        }

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
        YYABORT;


      yydestruct ("Error: popping",
                  YY_ACCESSING_SYMBOL (yystate), yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  YY_IGNORE_MAYBE_UNINITIALIZED_BEGIN
  *++yyvsp = yylval;
  YY_IGNORE_MAYBE_UNINITIALIZED_END


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", YY_ACCESSING_SYMBOL (yyn), yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturnlab;


/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturnlab;


/*-----------------------------------------------------------.
| yyexhaustedlab -- YYNOMEM (memory exhaustion) comes here.  |
`-----------------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  goto yyreturnlab;


/*----------------------------------------------------------.
| yyreturnlab -- parsing is finished, clean up and return.  |
`----------------------------------------------------------*/
yyreturnlab:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval);
    }
  /* Do not reclaim the symbols of the rule whose action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
                  YY_ACCESSING_SYMBOL (+*yyssp), yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif

  return yyresult;
}

#line 492 "jucompiler.y"


struct node *newnode(enum category category, char *token) {
    struct node *new = malloc(sizeof(struct node));
    new->category = category;
    new->token = token;
    new->type = TypeNone;
    new->is_expr = 0;
    new->is_duplicate = 0;
    new->func_sig = NULL;
    new->line = 0;
    new->col = 0;
    new->children = NULL;
    new->tail = NULL;
    return new;
}

void addchild(struct node *parent, struct node *child) {
    if (parent == NULL || child == NULL) return;
    struct node_list *new = malloc(sizeof(struct node_list));
    new->node = child;
    new->next = NULL;
    if (parent->children == NULL) {
        parent->children = new;
        parent->tail = new;
    } else {
        if (parent->tail != NULL) {
            parent->tail->next = new;
            parent->tail = new;
        } else {
            struct node_list *curr = parent->children;
            while(curr->next != NULL) curr = curr->next;
            curr->next = new;
            parent->tail = new;
        }
    }
}

void free_list_and_node(struct node *n) {
    if (!n) return;
    struct node_list *curr = n->children;
    while (curr) {
        struct node_list *tmp = curr;
        curr = curr->next;
        free(tmp);
    }
    free(n);
}

const char *category_names[] = {
    "Program", "FieldDecl", "VarDecl", "MethodDecl", "MethodHeader", 
    "MethodParams", "ParamDecl", "MethodBody", "Block", "If", "While", 
    "Return", "Call", "Print", "ParseArgs", "Assign", "Or", "And", "Eq", 
    "Ne", "Lt", "Gt", "Le", "Ge", "Add", "Sub", "Mul", "Div", "Mod", 
    "Lshift", "Rshift", "Xor", "Not", "Minus", "Plus", "Length", "Bool", 
    "BoolLit", "Double", "Decimal", "Identifier", "Int", "Natural", 
    "StrLit", "StringArray", "Void"
};

void show(struct node *node, int depth) {
    if (node == NULL) return;
    for (int i = 0; i < depth; i++) printf("..");
    if (node->token != NULL) {
        if (node->category == StrLit) {
            printf("%s(\"%s\")", category_names[node->category], node->token);
        } else {
            printf("%s(%s)", category_names[node->category], node->token);
        }
    } else {
        printf("%s", category_names[node->category]);
    }

    if (print_sym && node->is_expr) {
        if (node->func_sig != NULL) {
            printf(" - %s\n", node->func_sig);
        } else if (node->type != TypeNone) {
            printf(" - %s\n", get_type_name(node->type));
        } else {
            printf("\n");
        }
    } else {
        printf("\n");
    }

    struct node_list *curr = node->children;
    while (curr) { show(curr->node, depth + 1); curr = curr->next; }
}

extern int verbose;
int syntax_errors = 0; 

// Adiciona este cabeçalho no topo do jucompiler.y se ainda não o tiveres feito
// void codegen_program(struct node *program);

extern int lexical_errors; 

int main(int argc, char *argv[]) {
    setvbuf(stdout, NULL, _IOFBF, 65536);
    
    int print_ast = 0;
    int run_semantics = 1; // Por defeito, corre semântica (Meta 4)
    int generate_code = (argc == 1); 

    if (argc > 1) {
        if (strcmp(argv[1], "-l") == 0 || strcmp(argv[1], "-1") == 0) {
            verbose = 1;
            while (yylex() != 0); 
            return 0;
        } 
        else if (strcmp(argv[1], "-e1") == 0) {
            verbose = 0;
            while (yylex() != 0); 
            return 0;
        } 
        else if (strcmp(argv[1], "-e2") == 0) {
            yyparse(); 
            return 0;
        } 
        else if (strcmp(argv[1], "-t") == 0) {
            print_ast = 1;
            run_semantics = 0; // FIX: Não correr semântica na Meta 2!
        }
        else if (strcmp(argv[1], "-s") == 0) {
            print_sym = 1;
            run_semantics = 1;
        }
        else if (strcmp(argv[1], "-e3") == 0) {
            run_semantics = 1;
        }
    }

    yyparse();

    if (syntax_errors == 0) {
        if (print_ast) {
            show(ast, 0);
        }
        
        // Só avança para a semântica se a flag permitir
        if (run_semantics) {
            build_symbol_tables(ast);
            annotate_ast(ast, NULL);
            
            if (print_sym) {
                print_symbol_tables();
                show(ast, 0);
            }
            
            // Geração de Código: Só avança se não houver NENHUM erro
            if (generate_code && semantic_errors == 0 && lexical_errors == 0) {
                codegen_program(ast);
            }
        }
    }
    return 0;
}

void yyerror(char *error) {
    syntax_errors++;
    printf("Line %d, col %d: %s: %s\n", error_line, error_col, error, error_yytext);
}
